"""
Loan Approval Prediction Application
Main entry point for the loan approval prediction system.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report
import joblib
import os


def load_data(filepath):
    """Load the loan approval dataset."""
    return pd.read_csv(filepath)


def preprocess_data(df):
    """Preprocess the data for training."""
    # Handle missing values
    df = df.fillna(df.mode().iloc[0])
    
    # Encode categorical variables
    le = LabelEncoder()
    categorical_cols = ['person_gender', 'person_education', 'person_home_ownership', 
                        'loan_intent', 'previous_loan_defaults_on_file', 'loan_status']
    
    for col in categorical_cols:
        if col in df.columns:
            df[col] = le.fit_transform(df[col])
    
    return df


def train_model(X_train, y_train):
    """Train a Random Forest classifier."""
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    return model


def evaluate_model(model, X_test, y_test):
    """Evaluate the trained model."""
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    report = classification_report(y_test, y_pred)
    return accuracy, report


def main():
    """Main function to run the loan approval prediction pipeline."""
    # Load data
    data_path = 'loan_approval_dataset_01.csv'
    if not os.path.exists(data_path):
        print(f"Dataset not found at {data_path}")
        return
    
    df = load_data(data_path)
    print(f"Loaded dataset with shape: {df.shape}")
    
    # Preprocess
    df = preprocess_data(df)
    
    # Split features and target
    X = df.drop('loan_status', axis=1)
    y = df['loan_status']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Train model
    model = train_model(X_train, y_train)
    
    # Evaluate
    accuracy, report = evaluate_model(model, X_test, y_test)
    print(f"Model Accuracy: {accuracy:.4f}")
    print(f"Classification Report:\n{report}")
    
    # Save model
    os.makedirs('mlruns', exist_ok=True)
    joblib.dump(model, 'mlruns/loan_approval_model.pkl')
    print("Model saved to mlruns/loan_approval_model.pkl")


if __name__ == '__main__':
    main()