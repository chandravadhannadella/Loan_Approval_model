"""
Loan Approval Prediction - Experiment Tracking
MLflow experiment tracking for loan approval model training.
"""

import mlflow
import mlflow.sklearn
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
import joblib
import os


def load_and_preprocess_data(filepath):
    """Load and preprocess the loan approval dataset."""
    df = pd.read_csv(filepath)
    
    # Handle missing values
    df = df.fillna(df.mode().iloc[0])
    
    # Encode categorical variables
    le = LabelEncoder()
    categorical_cols = ['gender', 'married', 'dependents', 'education', 
                        'self_employed', 'property_area', 'loan_status']
    
    for col in categorical_cols:
        if col in df.columns:
            df[col] = le.fit_transform(df[col])
    
    return df


def train_and_log_model(model, model_name, X_train, X_test, y_train, y_test, params=None):
    """Train a model and log metrics to MLflow."""
    with mlflow.start_run(run_name=model_name):
        # Log parameters
        if params:
            mlflow.log_params(params)
        
        # Train model
        model.fit(X_train, y_train)
        
        # Predict
        y_pred = model.predict(X_test)
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, average='weighted')
        recall = recall_score(y_test, y_pred, average='weighted')
        f1 = f1_score(y_test, y_pred, average='weighted')
        
        # Log metrics
        mlflow.log_metric("accuracy", accuracy)
        mlflow.log_metric("precision", precision)
        mlflow.log_metric("recall", recall)
        mlflow.log_metric("f1_score", f1)
        
        # Log model
        mlflow.sklearn.log_model(model, "model")
        
        print(f"{model_name} - Accuracy: {accuracy:.4f}, F1: {f1:.4f}")
        
        return model, accuracy


def main():
    """Run experiments with different models."""
    # Set MLflow tracking URI
    mlflow.set_tracking_uri("file:./mlruns")
    mlflow.set_experiment("loan_approval_experiment")
    
    # Load data
    data_path = 'loan_approval_dataset.csv'
    if not os.path.exists(data_path):
        print(f"Dataset not found at {data_path}")
        return
    
    df = load_and_preprocess_data(data_path)
    print(f"Loaded dataset with shape: {df.shape}")
    
    # Split features and target
    X = df.drop('loan_status', axis=1)
    y = df['loan_status']
    
    # Train-test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    
    # Define models to experiment with
    models = {
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
        "LogisticRegression": LogisticRegression(random_state=42, max_iter=1000),
        "SVM": SVC(random_state=42)
    }
    
    best_model = None
    best_accuracy = 0
    
    # Train and evaluate each model
    for name, model in models.items():
        trained_model, accuracy = train_and_log_model(
            model, name, X_train, X_test, y_train, y_test
        )
        
        if accuracy > best_accuracy:
            best_accuracy = accuracy
            best_model = trained_model
    
    # Save best model
    os.makedirs('mlruns', exist_ok=True)
    joblib.dump(best_model, 'mlruns/best_model.pkl')
    print(f"\nBest model saved with accuracy: {best_accuracy:.4f}")


if __name__ == '__main__':
    main()